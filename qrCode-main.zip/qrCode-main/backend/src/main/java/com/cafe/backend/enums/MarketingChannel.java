package com.cafe.backend.enums;

public enum MarketingChannel {
    SMS,
    WHATSAPP,
    BOTH
}
