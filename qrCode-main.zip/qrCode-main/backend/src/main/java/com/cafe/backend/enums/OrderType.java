package com.cafe.backend.enums;

public enum OrderType {
    TABLE,
    WALK_IN
}
