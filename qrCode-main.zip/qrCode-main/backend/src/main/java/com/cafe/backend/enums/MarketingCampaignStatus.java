package com.cafe.backend.enums;

public enum MarketingCampaignStatus {
    DRAFT,
    SENDING,
    COMPLETED,
    PARTIALLY_FAILED,
    FAILED
}