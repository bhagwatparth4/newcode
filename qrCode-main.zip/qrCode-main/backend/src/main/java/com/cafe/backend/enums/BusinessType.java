package com.cafe.backend.enums;

public enum BusinessType {

    SMALL_CAFE,
    LARGE_CAFE,
    RESTAURANT
}