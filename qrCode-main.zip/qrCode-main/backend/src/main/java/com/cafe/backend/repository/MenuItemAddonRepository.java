package com.cafe.backend.repository;

import com.cafe.backend.entity.MenuItemAddon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuItemAddonRepository extends JpaRepository<MenuItemAddon, Long> {
}