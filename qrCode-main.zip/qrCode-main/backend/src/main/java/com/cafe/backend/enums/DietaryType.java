package com.cafe.backend.enums;

public enum DietaryType {
    VEG,
    NON_VEG
}
