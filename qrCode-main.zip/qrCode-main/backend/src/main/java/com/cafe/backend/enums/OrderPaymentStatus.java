package com.cafe.backend.enums;

public enum OrderPaymentStatus { PENDING, PAID }