package com.cafe.backend.enums;

public enum PaymentMethod { ONLINE, CASH }