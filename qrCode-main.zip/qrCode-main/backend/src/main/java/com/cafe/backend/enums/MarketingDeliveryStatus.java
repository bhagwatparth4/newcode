package com.cafe.backend.enums;

public enum MarketingDeliveryStatus {
    PENDING,
    SENT,
    DELIVERED,
    FAILED,
    OPTED_OUT
}