package com.cafe.backend.enums;

public enum OrderStatus {
    PAYMENT_PENDING,
    PAID,
    PREPARING,
    READY,
    COMPLETED,
    CANCELLED
}
