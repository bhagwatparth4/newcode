package com.cafe.backend.enums;

public enum DiscountType {
    PERCENTAGE,
    FIXED
}